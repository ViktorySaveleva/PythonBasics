# Первое задание
name = 'Вика'
age = 27
year = 1994
print ('Мое имя: ', name)
print ('Мой возраст: ', age)
print ('Мой год рождения: ', year)
name = input('Введите ваше имя: ')
age = input('Введите ваш возраст: ')
year = input ('Введите год вашего рождения: ')
print (f"Привет,  {name} {age} лет {year} года рождения")



