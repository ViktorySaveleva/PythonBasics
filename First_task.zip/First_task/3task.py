n = (input('Введите число: '))
n = str(n)
nn = n + n
#print(nn)
nnn = n + n + n
#print(nnn)
#n = int(n)
#nn = int(nn)
#nnn = int(nnn)
s = int(n) + int(nn) + int(nnn)
print(s)